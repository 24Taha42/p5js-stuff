let horse
let mrw
let happysc
let i = 0
let happies = 1
let balloon
let horsewidth
let horseheight

function setup() {
  createCanvas(windowWidth, windowHeight);
  horse = loadImage('jamesjean.jpeg')
  mrw = loadImage('face.png')
  happysc = loadImage('happybdaywh.png')
  balloon = loadImage('redball.png')
  frameRate(300)
  background(0);
  horseheight = 1180*(windowWidth/1500)
  horsewidth = windowWidth
}

function cursed(){
  imageMode(CORNER)
  image(horse, 0, 0, horsewidth, horseheight)
  image(mrw, horsewidth/2.3, (windowHeight-(windowHeight-horseheight))/10.5, (horsewidth/10), (horsewidth/10))
}

function happy(num){
  push();
  imageMode(CENTER)
  angleMode(DEGREES)
  tint(250-(num*14), 230-(num*10), 180-(num*8))
  translate(horsewidth*0.5, 1.3*(horsewidth*(284/749)))
  rotate(frameCount % 360)
  image(happysc, ((num*100)/happies), ((num*100)/happies), (horsewidth/4), ((284*horsewidth/749)/4))
  pop();
}

function balloons(){
  image(balloon, horsewidth/6, (windowHeight-(windowHeight-horseheight))/3, horsewidth/20, windowWidth/20)
  image(balloon, horsewidth/1.2, (windowHeight-(windowHeight-horseheight))/3, horsewidth/20, horsewidth/20)
}

function draw() {
  let winaspect = windowWidth/windowHeight
  if (winaspect < 1.37){
    cursed();
    if (frameCount % 200 == 0){
      happies++;
    }
    for (let i = 0; i < happies; i++){
      happy(i); }
    if (frameCount % 50 > 10){
      balloons();
    }
  }
  else{
    fill(255)
    textAlign(CENTER)
    textSize(windowHeight/20)
    text("Please make your window more squarish", windowWidth/2, windowHeight/2)
  }
} 