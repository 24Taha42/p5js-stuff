let tileedge = 15
let tiles = []
let message = ["Nadia,", "Will You", "Make My", "Hoco", "A Love Story?"]
let message2 = ["Just", "Say", "Yes"]
// color palette: https://www.schemecolor.com/blue-purple-green.php#google_vignette
let cursive;
let blessive;
let flower = []
let flors = []
let heart;
let heartpos = [];
let streamers = [];
let forwardness = 0;
let streamercount = 0;
let colors = [[144,241,239], [255,179,169], [242,126,161], [193,251,164], [123,241,168], [186,160,194], [111,115,210]]
//light blue, orange, red, light green, medium green, purple, cyan
let songcheck = false;

class Block{
  constructor(x, y, delay){
    this.x = x
    this.y = y
    this.delay = delay + (15*(dist((this.x+(tileedge/2))/ (adjwidth/adjheight), this.y+(tileedge/2), 0, 0)))
  }
  
  render(){
    let distancepar = (dist((this.x+(tileedge/2))/ (adjwidth/adjheight), this.y+(tileedge/2), 0, 0)/12);
    if (millis() < this.delay){
      push();
      noStroke();
      //fill('#228ee3')
      fill(34-distancepar,143-distancepar,243-distancepar)
      rect(this.x, this.y, tileedge, tileedge)
      pop();
    }
  }
  
  fillcolor(){
    if (dist(this.x+(tileedge/2), this.y+(tileedge/2), (adjwidth/2)+marginx, (adjheight/2)+marginy) < 0){
      return '#3377ff';
    }
    else{
      return '#228ee3';
    }
  }
}

class Partystrings{
  constructor(pos, phase){
    this.pos = pos
    this.phase = phase
    this.length = 0
    this.stringcolor = [colors[int(random(6))], colors[int(random(6))], colors[int(random(6))], colors[int(random(6))], colors[int(random(6))], colors[int(random(6))], colors[int(random(6))], colors[int(random(6))]]
  }
  
  printvars(){
    print(this.stringcolor[0])
  }
  
  render(){
    push();
    strokeWeight(7)
    angleMode(DEGREES)
    forwardness = int(millis()/20) % 60
    for (let i = 0; i < 8; i++){
      stroke(this.stringcolor[i])
      line(this.pos.x + ((cos(i*45) * forwardness)), this.pos.y + (sin(i*45) * forwardness), this.pos.x + ((cos(i*45) * forwardness * 1.25)), this.pos.y + ((sin(i*45) * forwardness * 1.25)))
    }
    pop();
  }
  
  changepos(){
    this.pos.x = random(margin[0], width-margin[0])
    this.pos.y = random(margin[1], height-margin[1])
  }
  
}

function happybday(){
  push();
  noStroke()
  fill(255)
  textSize(height*80/width)
  textAlign(CENTER)
  textFont(cursive)
  for (let i = 0; i < message.length; i++){
    text(message[i], (i+1)*adjwidth/ (message.length+1), (i+1)*adjheight/ (message.length+1)) }
  pop();
  push();
  if (millis() > 10*dist(0,0,adjwidth, adjheight)){
    textSize(height*50/width)
    textFont(blessive)
    textStyle(BOLD)
    fill('#ffea66')
    text(message2[0], (5.5*width)/8, height/8)
    if (millis() > 11*dist(0,0,adjwidth, adjheight)){
      textSize(height*70/width)
      text(message2[1], (width/5) , (6.4*height)/8)
      if (millis() > 12*dist(0,0,adjwidth, adjheight)){
        textSize(height*90/width)
        text(message2[2], (9*width)/10, (height/2)) 
      }
    }
  }
  pop();
}

function hearts(){
  imageMode(CENTER)
  for (let i = 0; i < message.length+1; i++){
    push();
    translate((i+0.4)*adjwidth/ (message.length+1), (i+0.4)*adjheight/ (message.length+1))
    image(heart, 0, 0, width/25, width/25)
    pop();
  }
}

class Rose{
  constructor(x, y, delay, rotdelay, flowertype){
    this.x = x; this.y = y; this.delay = delay + (15*(dist((this.x+(tileedge/2))/ (adjwidth/adjheight), this.y+(tileedge/2), 0, 0))); this.rotdelay = rotdelay; this.flowertype = flowertype;
  }
  
  render(){
    imageMode(CENTER)
    push();
    translate(this.x, this.y)
    let maxtime = min(((millis()-this.delay)*10), height*height/4)
    rotate(((log(maxtime))*PI)+this.rotdelay)
    image(flower[this.flowertype], 0, 0, width/5, max( min( ((millis()-this.delay)*10/height), (height/5) ), 1 ), 0, 0, flower[this.flowertype].width, flower[this.flowertype].height, CONTAIN)
    pop();
  }
  
}

function gridsetup(){
  let j = 0;
  
  while (j < (adjheight/tileedge)){
    let i = 0;
    while (i < (adjwidth/tileedge)){
      tiles[((adjwidth/tileedge)*j)+i] = new Block((i*tileedge)+marginx, (j*tileedge)+marginy, random(dist(0,0,adjwidth, adjheight),2*dist(0,0,adjwidth, adjheight)))
      i++;
    }
    j++;
  }
}

function florssetup(){
  let florsx = [(width/6.5) + random(-width/20, width/20), (width/2.55) + random(-width/20, width/20), (width*3)/4 + random(-width/20, width/20), (width/1.9) + random(-width/20, width/20)]
  let florsy = [(height*2.4)/5 + random(-height/20, height/20), (height*6)/8 + random(-height/20, height/20), height/2.5 + random(-height/20, height/20), (height/7) + random(-height/20, height/20)]
  for (let i = 0; i < 4; i++){
    flors[i] = new Rose(florsx[i], florsy[i], 0, PI*(i+random(-0.25,0.25)), (i % flower.length))
  }
}

function preload(){
  cursive = loadFont('fancyscript.ttf')
  blessive = loadFont('Malberg.ttf')
  flower[0] = loadImage('pinkpixelflower.png')
  //flower[1] = loadImage('yellowpixelflower.png')
  //flower[2] = loadImage('greenpixelflower.png')
  flower[1] = loadImage('aquapixelflower.png')
  heart = loadImage('heart.png')
  lovestory = loadSound('lovestory-cut3.mp3')
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  
  adjwidth = width - (width % tileedge)
  marginx = (width-adjwidth)/2
  adjheight = height - (height % tileedge)
  marginy = (height-adjheight)/2
  
  florssetup();
  
  gridsetup();
  
  flowerpos = [createVector(width/15, (height*5.8)/10), createVector((width*7)/8, height/10), createVector(width)]
  
}

function draw() {
  background('#6633C6');
  push();
  noStroke();
  fill('#FFD700')
  rect(0,0,marginx,height)
  rect(0,0,width, marginy)
  rect(width-marginx, 0, width, height)
  rect(0,height-marginy, width, height)
  pop();
  
  for (h = 0; h < flors.length; h++){ flors[h].render() }
  
  hearts()
  
  happybday()
  
  if (streamercount > 0){
    for (let m = 0; m < streamercount; m++){
      streamers[m].render() } 
  }
  
  for (i = 0; i < tiles.length; i++){ tiles[i].render() }
  
  if (lovestory.currentTime() > 14){lovestory.setVolume((lovestory.duration()-lovestory.currentTime())/(lovestory.duration()-14)) }
}

function mouseClicked(){
  if (dist((9*width)/10, (height/2), mouseX, mouseY) < width/15){
    streamers[streamercount] = new Partystrings(createVector(mouseX,mouseY), streamercount)
  streamercount++
  }
  
}

function keyTyped(){  
  if (key === 'n'){
    lovestory.play()
    lovestory.setVolume(1)
  }
}