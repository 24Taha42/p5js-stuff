let wins = 0
let prob = 0.5
let countFrame = 0
let flipflop = 0
let percent;
let downness; let downess2;
let fontsize;

function setup() {
  createCanvas(windowWidth, windowHeight);
  background(255);
  
  
  strokeWeight(4)
  stroke('#ff595e')
  percent = 100
  
  sliderProb = createSlider(0, 1, 0.50, 0.01);
  
}

function fontSize(){
  if (width/height < 1){
    fontsize = height/28; }
  else if (width/height > 2){
    fontsize = (width*width*0.001)/48; }
  else if (width/height >= 1 && width/height <= 2){
    fontsize = width/25; }
}

function rolldie(p){
  let r = random(1,100)
  if (r < p*100){
    wins += 1
  }
}

function drawText(){
  push()
    fill(255)
    stroke(255)
    rect(windowWidth/10,downness,(4*windowWidth)/5, windowHeight/6)
  pop()
  push()
    textAlign(CENTER)
    fill(230)
    textSize(fontsize)
    text('~' + nf(percent,2,2) + '%',  windowWidth/2, downness2)
  pop()
  push()
    textAlign(CENTER)
    noStroke()
    fill(0)
    textSize(fontsize/1.5)
    text('P(x) = ' + sliderProb.value()*100 + '% (updates at end of screen)',  windowWidth/2, downness2+windowHeight/20)
  pop()
}

function draw() {
  countFrame = frameCount % (windowWidth*2)
  
  if (frameCount % 10 == 0){
    percent = (wins/countFrame)*100
  }
  
  if (countFrame/2 < windowWidth-1 && countFrame > 1){
    rolldie(prob)
    place = (1-(wins/countFrame))*windowHeight
    point((countFrame/2), place)
  }
  
  else{
    flipflop++
    wins = 0
    if (flipflop % 5 == 0){
      stroke('#ff595e') }
    else if (flipflop % 5 == 1){
      stroke('#ffca3a') }
    else if (flipflop % 5 == 2){
      stroke('#8ac926') }
    else if (flipflop % 5 == 3){
      stroke('#1982c4') }
    else if (flipflop % 5 == 4){
      stroke('#6a4c93') }
    
    if (prob != sliderProb.value()){
      background(255)
      prob = sliderProb.value()
    }
    
    if (prob <= 0.50){
    downness = windowHeight/5.4
    downness2 = windowHeight/4
    }
    else if (prob > 0.50){
      downness = (78*windowHeight)/100
      downness2 = (5*windowHeight)/6
    }
    
    sliderProb.position(width/2.5, downness2+(windowHeight/15));
    sliderProb.center('horizontal')
    
    fontSize()
    
    push()
      stroke('darkgreen')
      strokeWeight(1)
      line(0,windowHeight-(prob*windowHeight), windowWidth, windowHeight-(prob*windowHeight))
    pop()
    push()
      stroke(230)
      strokeWeight(2)
      fill(0)
      textAlign(CENTER)
      textSize(fontsize)
      text('Cumulative Frequency of Moving Line:',  windowWidth/2, downness2-(windowHeight/12))
    pop()
  }
  
  drawText()

}