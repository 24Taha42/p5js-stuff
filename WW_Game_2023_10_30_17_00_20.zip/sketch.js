let colorlist = ['darkgreen', 'purple', 'turquoise', 'red']
let colorlist2 = ['darkgreen', 'purple', 'darkgreen', 'purple', 'turquoise', 'red', 'turquoise', 'red']
let fontserif; 
let bkpic;
let scenenum = 0;
let playerCount;
let problem = ["Only wearing underwear", "Aliens", "Being chased", "A nosebleed", "Locked inside", "Stuffed animals come to life", "Only source of water is far away", "Dropped phone in water", "Stranded", "Have to make ethical descision", "Pants are on fire", "Late for a meeting", "Robbery", "Extreme Heat", "Car Chase", "Phone on 1%", "Car broke down", "Bankruptcy", "Leg fell asleep", "Allergies", "Ate way too much", "Fire", "Stuck in mud", "Fell into a deep hole", "Air is smoky", "Dry skin", "Lost keys", "Hard math problem", "Hole in a bucket", "Need AA Batteries", "Rabid animal", "Plant monster", "Ninjas", "Severe Allergies", "Thirst", "Leakage", "Lightning"]
let place = ["Ancient Rome", "TAAJY's house", "The gym", "Mars Colony", "Atlantis", "Cancelot", "Your birth-house", "The hospital", "Supermarket", "Park", "Amazon Rainforest", "Steamboat", "Bejing", "Empty island", "Primary school", "A Greenhouse", "The mall", "Burger King", "Moving Truck", "Boss's office", "Harvard", "Mt. Everest", "Gobi Desert", "Movie theater", "Airplane", "Nice beach", "Cruise ship", "Video game", "Burj Khalifa", "Parking lot", "Clothes store", "The moon", "The Pyramids", "Lighthouse", "Warehouse", "Middle Earth", "Bazaar", "Orchard", "Carnival"]
let thing = ["Handaxe", "Sewing machine", "Extension cord", "Ice Cream Cone", "Headphones", "House keys", "Computer", "$20 bill", "Gold coin", "Children's book", "Paper aeroplane", "Hammer", "Pen", "Longsword", "Lightning rod", "Invisibility potion", "Crab", "Big stick", "Pebble", "Chair", "Paper towel", "Witch's robe", "Venus flytrap", "Bubble gum", "Bouncy ball", "Baby", "Flag", "Rotary phone", "Rotisserie Chicken", "Parrot", "Koala", "Kettle", "Bottle", "Clock", "Rope", "Meter stick", "Lightbulb", "Glasses", "Potato gun", "Duckling", "Ziploc bag", "Tissue box", "Towel", "Supercomputer"]
let PPTnum = [0,0,0];
let Gcounter1;
let pencilpic;
let homebutt;
let helpbutt;
let Lcounter1 = 0;
let starttime;
let nowtime = 180;
let fontsize;




function preload() {
  fontserif = loadFont('SFCompact.ttf');
  bkpic = loadImage('blback.jpg');
  pencilpic = loadImage('pencil.png')
  homebutt = loadImage('home.webp')
  helpbutt = loadImage('QMark.webp')
  Gcounter1 = 0;
}

function fontSize(){
  if (width/height < 1){
    fontsize = height/6;
  }
  else if (width/height > 2){
    fontsize = width/8;
  }
  else if (width/height >= 1 && width/height <= 2){
    fontsize = height/4.5;
  }
  
}

function generatePPT(){
  fill(255);
  textAlign(CENTER, CENTER);
  
  if (playerCount == 1){
    textSize(fontsize/2.4);
    text('Place: ' + place[PPTnum[0]], width/16, height/16, (7/8)*width);
    text('Problem: ' + problem[PPTnum[1]], width/16, height/3, (7/8)*width);
    text('Thing: ' + thing[PPTnum[2]], width/16, height/2+height/4, (7/8)*width);
  }
  else if (playerCount == 2){
    textSize(fontsize/3);
    text('Place: ' + place[PPTnum[0]], width/16, height/10, (3/8)*width);
    text('Problem: ' + problem[PPTnum[1]], width/16, height/3, (3/8)*width);
    text('Thing: ' + thing[PPTnum[2]], width/16, (6/8)*height, (3/8)*width);
    
    text('Place: ' + place[PPTnum[3]], (9/16)*width, height/10, (3/8)*width);
    text('Problem: ' + problem[PPTnum[4]], (9/16)*width, height/3, (3/8)*width);
    text('Thing: ' + thing[PPTnum[5]], (9/16)*width, height/2+height/4, (3/8)*width);
  }
  else if (playerCount == 3) {
    textSize(fontsize/4.7);
    text('Place: ' + place[PPTnum[0]], width/16, (1/18)*height, (3/8)*width);
    text('Problem: ' + problem[PPTnum[1]], width/16, (1/6)*height, (3/8)*width);
    text('Thing: ' + thing[PPTnum[2]], width/16, (3/8)*height, (3/8)*width);
    
    text('Place: ' + place[PPTnum[3]], (9/16)*width, (1/18)*height, (3/8)*width);
    text('Problem: ' + problem[PPTnum[4]], (9/16)*width, (1/6)*height, (3/8)*width);
    text('Thing: ' + thing[PPTnum[5]], (9/16)*width, (3/8)*height, (3/8)*width);
    
    text('Place: ' + place[PPTnum[6]], width/16, (10/18)*height, (3/8)*width);
    text('Problem: ' + problem[PPTnum[7]], width/16, (4/6)*height, (3/8)*width);
    text('Thing: ' + thing[PPTnum[8]], width/16, (7/8)*height, (3/8)*width);
  }
  else if (playerCount == 4) {
    textSize(fontsize/4.7);
    text('Place: ' + place[PPTnum[0]], width/16, (1/18)*height, (3/8)*width);
    text('Problem: ' + problem[PPTnum[1]], width/16, (1/6)*height, (3/8)*width);
    text('Thing: ' + thing[PPTnum[2]], width/16, (3/8)*height, (3/8)*width);
    
    text('Place: ' + place[PPTnum[3]], (9/16)*width, (1/18)*height, (3/8)*width);
    text('Problem: ' + problem[PPTnum[4]], (9/16)*width, (1/6)*height, (3/8)*width);
    text('Thing: ' + thing[PPTnum[5]], (9/16)*width, (3/8)*height, (3/8)*width);
    
    text('Place: ' + place[PPTnum[6]], width/16, (10/18)*height, (3/8)*width);
    text('Problem: ' + problem[PPTnum[7]], width/16, (4/6)*height, (3/8)*width);
    text('Thing: ' + thing[PPTnum[8]], width/16, (7/8)*height, (3/8)*width);
    
    text('Place: ' + place[PPTnum[9]], (9/16)*width, (10/18)*height, (3/8)*width);
    text('Problem: ' + problem[PPTnum[10]], (9/16)*width, (4/6)*height, (3/8)*width);
    text('Thing: ' + thing[PPTnum[11]], (9/16)*width, (7/8)*height, (3/8)*width);
  }
  else if (playerCount == 8) {
    textSize(fontsize/7);
    text('Place: ' + place[PPTnum[0]], width/32, (1/18)*height, (3/16)*width);
    text('Problem: ' + problem[PPTnum[1]], width/32, (1/6)*height, (3/16)*width);
    text('Thing: ' + thing[PPTnum[2]], width/32, (3/8)*height, (3/16)*width);
    
    text('Place: ' + place[PPTnum[3]], (9/32)*width, (1/18)*height, (3/16)*width);
    text('Problem: ' + problem[PPTnum[4]], (9/32)*width, (1/6)*height, (3/16)*width);
    text('Thing: ' + thing[PPTnum[5]], (9/32)*width, (3/8)*height, (3/16)*width);
    
    text('Place: ' + place[PPTnum[6]], width/32, (10/18)*height, (3/16)*width);
    text('Problem: ' + problem[PPTnum[7]], width/32, (4/6)*height, (3/16)*width);
    text('Thing: ' + thing[PPTnum[8]], width/32, (7/8)*height, (3/16)*width);
    
    text('Place: ' + place[PPTnum[9]], (9/32)*width, (10/18)*height, (3/16)*width);
    text('Problem: ' + problem[PPTnum[10]], (9/32)*width, (4/6)*height, (3/16)*width);
    text('Thing: ' + thing[PPTnum[11]], (9/32)*width, (7/8)*height, (3/16)*width);
    
    text('Place: ' + place[PPTnum[12]], (25/32)*width, (1/18)*height, (3/16)*width);
    text('Problem: ' + problem[PPTnum[13]], (25/32)*width, (1/6)*height, (3/16)*width);
    text('Thing: ' + thing[PPTnum[14]], (25/32)*width, (3/8)*height, (3/16)*width);
    
    text('Place: ' + place[PPTnum[15]], (17/32)*width, (1/18)*height, (3/16)*width);
    text('Problem: ' + problem[PPTnum[16]], (17/32)*width, (1/6)*height, (3/16)*width);
    text('Thing: ' + thing[PPTnum[17]], (17/32)*width, (3/8)*height, (3/16)*width);
    
    text('Place: ' + place[PPTnum[18]], (25/32)*width, (10/18)*height, (3/16)*width);
    text('Problem: ' + problem[PPTnum[19]], (25/32)*width, (4/6)*height, (3/16)*width);
    text('Thing: ' + thing[PPTnum[20]], (25/32)*width, (7/8)*height, (3/16)*width);
    
    text('Place: ' + place[PPTnum[21]], (17/32)*width, (10/18)*height, (3/16)*width);
    text('Problem: ' + problem[PPTnum[22]], (17/32)*width, (4/6)*height, (3/16)*width);
    text('Thing: ' + thing[PPTnum[23]], (17/32)*width, (7/8)*height, (3/16)*width);
  }
}

function titleScreen() {
  fill(0,157,196)
  rect(0,0,width,height)
  //image(bkpic,0,0,width,height);
  fill(255);
  textSize(fontsize/1.4);
  textAlign(CENTER);
  text('Weecliffe Weekly Game', width/8, height/2-height/5, width*(3/4));
  textSize(fontsize/2.7);
  text('click anywhere to continue', width/8, height*(5/6), width*(3/4));
}

function chooseTeams(){
  //image(bkpic,0,0,width,height)
  rectMode(CORNER)
  fill(0,157,196);
  rect(0,0,width,height);
  textAlign(CENTER,CENTER);
  textSize(fontsize/1.1);
  fill(255);
  text("How many teams?", width/16, height/5, width*(7/8));
  
  textSize(fontsize/2);
  
  if (width/height < 1.8){
    for (let i = 0; i < 4; i++){
      fill(255,30,30);
      rect(i*(width/4)+width/12, 4*(height/5), width/10, height/10);
      fill(255);
      text(i+1, i*(width/4)+(width/7.5), 4.2*(height/5)); }
  }  
  else if (width/height >= 1.8){
    for (let i = 0; i < 5; i++){
      fill(255,30,30);
      rect(i*(width/5)+width/18, 4*(height/5), width/12, height/9.3);
      fill(255);
      if (i < 4) {
        text(i+1, i*(width/5)+(width/10), 4.153*(height/5)); }
      else if (i == 4){
        text("8", i*(width/5)+(width/10), 4.153*(height/5))
      }
    }
  }
}

function begin(){
  rectMode(CORNER)
  if (playerCount == 8){
    for (let i = 0; i < 4; i++){
      for (let i2 = 0; i2 < 2; i2++){
        fill(colorlist2[i+(i2*4)])
        rect(i*width/4, i2*height/2, width/2, height/2);
        fill(255);
        textSize(width/4)
        textAlign(CENTER, CENTER);
        text(i+(i2*4)+1, (i*width/4)+width/8, (i2*height/2)+height/5)
      }
    }
  }
  else if (playerCount == 4 || playerCount == 3){
    for (let i = 0; i < 2; i++){
      for (let i2 = 0; i2 < 2; i2++){
        fill(colorlist[i+(i2*2)])
        rect(i*width/2, i2*height/2, width/2, height/2);
        fill(255);
        textSize(max(width, height)/4)
        textAlign(CENTER, CENTER);
        text(i+(i2*2)+1, (i*width/2)+width/4, (i2*height/2)+height/4)
        if (playerCount == 3){
          fill(colorlist[3])
          rect(width/2,height/2,width/2,height/2)
        }
      }
    }
  }
  else if (playerCount == 2){
    fill(colorlist[2]);
    rect(0,0,width/2,height);
    fill(colorlist[3]);
    rect(width/2,0,width/2,height);
    fill(255);
    textSize(max(width, height)/4)
    textAlign(CENTER, CENTER);
    text('1', width/4, height/2)
    text('2', width*(3/4), height/2)
  }
  else if (playerCount == 1){
    fill(colorlist[2]);
    rect(0,0,width,height);
  }
  fill('green');
  ellipseMode(CENTER);
  if (playerCount != 8){ 
    circle(width/2,height/2,width/4); }
  else if (playerCount == 8){
    circle(width/2, height/2, width/5)
  }
  fill(255);
  textAlign(CENTER,CENTER);
  textSize(width/20);
  text("Begin",width/2,height/2-height/100);
}

function promptGiver(){
  
  nowtime = int(120-((millis()-starttime)/1000));
  if (nowtime > 0){
    if (playerCount == 4 || playerCount == 3){
      for (let i = 0; i < 2; i++){
        for (let i2 = 0; i2 < 2; i2++){
          fill(colorlist[i+(i2*2)]);
          rect(i*width/2, i2*height/2, width/2, height/2);
          generatePPT();
        }
      }
      fill('green');
      ellipseMode(CENTER);
      circle(width/2,height/2,width/5);
      fill(255);
      textAlign(CENTER,CENTER);
      textSize(width/20);
      text(nowtime,width/2,height/2-height/100);
    }
    else if (playerCount == 8){
      for (let i = 0; i < 4; i++){
        for (let i2 = 0; i2 < 2; i2++){
          fill(colorlist2[i+(i2*4)])
          rect(i*width/4, i2*height/2, width/2, height/2);
          generatePPT();
        }
      }
      fill('green');
      ellipseMode(CENTER);
      circle(width/2,height/2,width/11);
      fill(255);
      textAlign(CENTER,CENTER);
      textSize(width/20);
      text(nowtime,width/2,height/2-height/100);  
    }
    else if (playerCount == 2){
      rectMode(CORNER)
      fill(colorlist[2]);
      rect(0,0,width/2,height);
      fill(colorlist[3]);
      rect(width/2,0,width/2,height);
      generatePPT();
      fill('green')
      rectMode(CENTER)
      rect(width/2,height*(19/20),width/8,height/8)
      fill(255);
      textAlign(CENTER,CENTER);
      textSize(width/20);
      text(nowtime,width/2,height*0.93);
    }
    else if (playerCount == 1){
      rectMode(CORNER)
      fill(colorlist[2]);
      rect(0,0,width,height);
      generatePPT();
      fill('green')
      rect(0,height*(9/10),width/8,height/8)
      fill(255);
      textAlign(CENTER,CENTER);
      textSize(width/20);
      text(nowtime,width/20,height*0.95);
    } }
  if (nowtime <= 0) {
    
    if (playerCount == 1){
      fill('pink')
      rectMode(CORNERS)
      rect(0,height*(7/8),width,height)
      fill(255);
      textAlign(CENTER,CENTER);
      textSize(width/20);
      text("Time's up!",width/2,height*0.93); 
    }
    else if (playerCount >= 2){
      fill('pink')
      rectMode(CENTER)
      rect(width/2,height/2,width/8,height)
      fill(255);
      textAlign(CENTER,CENTER);
      textSize(width/20);
      text("Time\nis\nup!",width/2,height/2); }
  }

}

function helpScreen(){
  rectMode(CORNER)
  fill(0,157,196)
  rect(0,0,width,height)
  textAlign(CENTER);
  fill(255);

  textSize(fontsize/3);
  text('How to Play', width/2, height/10);
  textSize(fontsize/5);
  text('1. Divide into up to 4 teams and a judge\n\n2. Give each team a number\n\n3. Press begin; each team creates a story involving the place, problem, and thing that show up on the tile corresponding to their team number before time runs out\n\n4. The story must have a plot and characters and is judged when time is up; click the home button to start', width/16, height/5, width*(7/8));
  
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  background(255)
  textFont(fontserif);
  noStroke();
  fontSize();
}

function draw() {
  if (scenenum == 0) {
    titleScreen();
  }
  else if (scenenum == 1) {
    chooseTeams();
  }
  else if (scenenum == 2){
    begin();
  }
  else if (scenenum == 3){
    promptGiver();
  }
  else if (scenenum == 4) {
    helpScreen();
  }
  image(homebutt,height/80, height/80, max(width,height)/25, max(width,height)/25)
  image(helpbutt,width*(95/100), height/80, max(width,height)/25, max(width,height)/25)
}

function touchStarted() {
  if (scenenum == 0) {
    scenenum = 4;
  }
  else if (scenenum == 1 && width/height < 1.8) {
    if (mouseX >= width/12 && mouseY >= 4*(height/5) && mouseX <= width/12+width/10 && mouseY <= height*(9/10)) {
      playerCount = 1;
      scenenum = 2;
    }
    else if (mouseX >= (1*(width/4))+width/12 && mouseY >= 2*(height/5) && mouseX <= (1*(width/4)+width/12)+width/10 && mouseY <= height*(9/10)) {
      playerCount = 2;
      scenenum = 2;
    }
    else if (mouseX >= (2*(width/4))+width/12 && mouseY >= 4*(height/5) && mouseX <= (2*(width/4)+width/12)+width/10 && mouseY <= height*(9/10)) {
      playerCount = 3;
      scenenum = 2;
    }
    else if (mouseX >= (3*(width/4))+width/12 && mouseY >= 4*(height/5) && mouseX <= (3*(width/4)+width/12)+width/10 && mouseY <= height*(9/10)) {
      playerCount = 4;
      scenenum = 2;
    }
  }
  else if (scenenum == 1 && width/height > 1.8) {
    if (mouseX >= width/18 && mouseY >= 4*(height/5) && mouseX <= width/8+width/10 && mouseY <= height*(9/10)) {
      playerCount = 1;
      scenenum = 2;
    }
    else if (mouseX >= (1*(width/5))+width/18 && mouseY >= 2*(height/5) && mouseX <= (1*(width/5)+width/18)+width/10 && mouseY <= height*(9/10)) {
      playerCount = 2;
      scenenum = 2;
    }
    else if (mouseX >= (2*(width/5))+width/18 && mouseY >= 4*(height/5) && mouseX <= (2*(width/5)+width/18)+width/10 && mouseY <= height*(9/10)) {
      playerCount = 3;
      scenenum = 2;
    }
    else if (mouseX >= (3*(width/5))+width/18 && mouseY >= 4*(height/5) && mouseX <= (3*(width/5)+width/18)+width/10 && mouseY <= height*(9/10)) {
      playerCount = 4;
      scenenum = 2;
    }
    else if (mouseX >= (4*(width/5))+width/18 && mouseY >= 4*(height/5) && mouseX <= (4*(width/5)+width/18)+width/10 && mouseY <= height*(9/10)) {
      playerCount = 8;
      scenenum = 2;
    }
  }
  else if (scenenum == 2){
    if (Math.sqrt(((mouseX-width/2)*(mouseX-width/2))+((mouseY-height/2)*(mouseY-height/2)))<width/8){
      scenenum = 3;
      PPTnum[0] = int(random(0,place.length));
      PPTnum[1] = int(random(0,problem.length));
      PPTnum[2] = int(random(0,thing.length));
      PPTnum[3] = int(random(0,place.length));
      PPTnum[4] = int(random(0,problem.length));
      PPTnum[5] = int(random(0,thing.length));
      PPTnum[6] = int(random(0,place.length));
      PPTnum[7] = int(random(0,problem.length));
      PPTnum[8] = int(random(0,thing.length));
      PPTnum[9] = int(random(0,place.length));
      PPTnum[10] = int(random(0,problem.length));
      PPTnum[11] = int(random(0,thing.length));
      if (width/height >= 1.8){
        PPTnum[12] = int(random(0,place.length));
        PPTnum[13] = int(random(0,problem.length));
        PPTnum[14] = int(random(0,thing.length));
        PPTnum[15] = int(random(0,place.length));
        PPTnum[16] = int(random(0,problem.length));
        PPTnum[17] = int(random(0,thing.length));
        PPTnum[18] = int(random(0,place.length));
        PPTnum[19] = int(random(0,problem.length));
        PPTnum[20] = int(random(0,thing.length));
        PPTnum[21] = int(random(0,place.length));
        PPTnum[22] = int(random(0,problem.length));
        PPTnum[23] = int(random(0,thing.length));
      }
      starttime = millis();
    }
  }
  if (mouseX < width/19 && mouseY < height/19){
    scenenum = 1;
  }
  if (mouseX > (18/20)*width && mouseY < height/18){
    scenenum = 4; 
  }
    
}