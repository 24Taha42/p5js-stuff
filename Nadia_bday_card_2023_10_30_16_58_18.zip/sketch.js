var rocket;
let rocketv;
let graphx = 0
let v0;
let therebelight = [];
let r, g, b;
let luna = -1;

class Orbs {
  constructor(coord, length, size) {
    this.coord = coord;
    this.length = length;
    this.size = size;
  }
  
  render(){
    push();
    noStroke()
    r = (50*(sin((millis()+this.coord+PI)/10)+1))+150
    b = (30*(sin((millis()+this.coord+0)/10)+1))+50
    g = (50*(sin((millis()+this.coord+HALF_PI)/10)+1))+150
    fill(r, g, b)
    translate(this.coord+(noise(millis()+this.coord)*2)+(mouseX*height/50/width), this.length+(noise(millis()+this.coord+1000)*2)+(mouseY/50))
    angleMode(DEGREES)
    rotate(45)
    ellipse(0, 0, this.size)
    pop();
  }
}

function moonshow(){
  push();
  if (dist(mouseX, mouseY, rocketv.x, rocketv.y) < 40){
    imageMode(CENTER)
    image(explosion, mouseX, mouseY, width/5, height/8, 0, 0, explosion.width, explosion.height, CONTAIN)
  }
  else{
    imageMode(CENTER)
    image(moon, mouseX, mouseY, width/5, height/8, 0, 0, moon.width, moon.height, CONTAIN)
  }
  pop();
}

function rocketpos(){
  rocketv.x = graphx
  rocketv.y = ((v0/width)*graphx*(graphx-width))+height
  
  push();
  imageMode(CENTER)
  translate(rocketv.x, rocketv.y)
  angleMode(DEGREES)
  rotate(0+((rocketv.x/width)*120))
  image(rocket, 0, 0, width/2, height/4, 0, 0, rocket.width, rocket.height, CONTAIN)
  pop();
  
}

function ballsetup(){
  let i = 0;
  let margin = height/50
  
  while (i < (width*height)/5000){
    therebelight[i] = new Orbs(random(margin,width-margin), random(margin, height-margin), height / 60)
    i++
  }
}

function happybday(){
  push();
  noStroke()
  fill('#0a0a30')
  rectMode(CENTER)
  rect(width/2,7*height/10,height*600/width, height/2.7)
  fill(255, millis()/10)
  textSize(height*80/width)
  textAlign(CENTER)
  textFont(cursive)
  text("Happy Birthday\nNadia!", width/2, 7*height/10)
  pop();
}

function preload(){
  rocket = loadImage("spacex.png")
  cursive = loadFont("GreatVibes-Regular.ttf")
  moon = loadImage("fullmoon.png")
  explosion = loadImage("explosion.png")
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  rocketv = createVector(0,0);
  v0 = (height*3)/width;
  ballsetup()
}

function draw() {
  background('#0a0a30');
  
  if (width/height < 16/10){
    push();
    fill(255)
    textSize(30)
    text("Please view in wider screen & refresh", windowWidth/20 , windowHeight/10, (windowWidth*9)/10, windowHeight)
    pop();
  }
  
  else {
    graphx = ((millis()/(15*height/width))-width/4) % width*1.5 
    
    let i = 0;
    while (i < (width*height)/5000){
      if (dist(mouseX, mouseY, therebelight[i].coord, therebelight[i].length) > 60){
        therebelight[i].render() 
      }
      i++ 
    }
    if (luna == 1){
      moonshow() }
    
    happybday()
    
    rocketpos()
  }
}

function mousePressed(){
  luna *= -1;
}