let counter = 0;
let colors = [[144,241,239], [255,179,169], [242,126,161], [193,251,164], [123,241,168], [186,160,194], [111,115,210]] //light blue, orange, red, light green, medium green, purple, cyan
let forwardness;
let margin = [];
let balloons = [];
let streamers = [];
let streamercount = 0;
let balloonobjects = [];

class Partystrings{
  constructor(pos, phase){
    this.pos = pos
    this.phase = phase
    this.length = 0
    this.stringcolor = [colors[int(random(6))], colors[int(random(6))], colors[int(random(6))], colors[int(random(6))], colors[int(random(6))], colors[int(random(6))], colors[int(random(6))], colors[int(random(6))]]
  }
  
  printvars(){
    print(this.stringcolor[0])
  }
  
  render(){
    push();
    strokeWeight(7)
    angleMode(DEGREES)
    forwardness = int(millis()/100) % 30
    for (let i = 0; i < 8; i++){
      stroke(this.stringcolor[i])
      line(this.pos.x + ((cos(i*45) * forwardness)), this.pos.y + (sin(i*45) * forwardness), this.pos.x + ((cos(i*45) * forwardness * 1.25)), this.pos.y + ((sin(i*45) * forwardness * 1.25)))
    }
    pop();
  }
  
  changepos(){
    this.pos.x = random(margin[0], width-margin[0])
    this.pos.y = random(margin[1], height-margin[1])
  }
  
}

class balloonclass{
  constructor(looks, pos){
    this.looks = looks
    this.pos = pos
  }
  
  render(){
    push();
    imageMode(CENTER)
    let tracker = millis()/30 % (height+margin[1])
    if (tracker >= height){this.pos+=randomGaussian(0,width/250)}
    translate(this.pos, height-(tracker+margin[1]))
    angleMode(DEGREES)
    rotate(10*sin(millis()/10))
    tint(this.looks[0],this.looks[1],this.looks[2], this.looks[3])
    image(balloons[1], 0, 0, width/9, height/4, 0, 0, balloons[1].width, balloons[1].height, CONTAIN)
    pop();
  }
}

/*
function streamersetup(){
  let tileedge = 200;
  let tilenum = [floor(width/tileedge), floor(height/tileedge)]
  
  for (let ycount = 0; ycount < tilenum[1]; ycount++){
    for (let xcount = 0; xcount < tilenum[0]; xcount++){
      streamers[counter] = new Partystrings(createVector(random((xcount*tileedge)+20, ((xcount+1)*tileedge)-20), random((ycount*tileedge)+20, ((ycount+1)*tileedge)-20)), counter)
      counter++
    }
  } 
} */

function balloonsetup(){
  balloons[0] = loadImage('balloon1.png')
  balloons[1] = loadImage('balloon2.png')
  balloonobjects[0] = new balloonclass([250, 180, 180, 150], margin[0])
  balloonobjects[1] = new balloonclass([255, 230, 230, 150], width-margin[0])
}

function happybirthday(){
  push();
  rectMode(CENTER)
  textAlign(CENTER)
  noStroke();
  fill(240,240,255)
  rect(width/2, height/1.8, width/2.5, height/3)
  textFont(cursive)
  textSize(width*height/10000)
  let percent = map(millis(), 0, 1000, 0, 100)
  if (percent >= 100){percent = 100}
  let modifier = map(percent, 0, 1000, 0, 140)
  fill(255-modifier, 255-percent, 255-modifier)
  text('Happy Birthday\nMrs. Wegscheid!', width/2, height/2)
  pop();
}

function balloonsdisp(){
  for (let i = 0; i < 2; i++){
    balloonobjects[i].render() } 
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  margin[0] = width/10
  margin[1] = height/10
  cursive = loadFont('GreatVibes-Regular.ttf')
  balloonsetup()
  streamers[streamercount] = new Partystrings(createVector(random(margin[0], width-margin[0]), random(margin[1], height-margin[1])), streamercount)
  streamercount++
}

function draw() {
  background(240,240,255);
  for (let m = 0; m < streamercount; m++){
    streamers[m].render() } 
  
  if (forwardness == 0){
    for (let m = 0; m < streamercount; m++){
      streamers[m].changepos() } }
  
  balloonsdisp()
  happybirthday()
}

function mousePressed(){
  streamers[streamercount] = new Partystrings(createVector(mouseX,mouseY), streamercount)
  streamercount++
}